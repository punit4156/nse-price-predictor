import yfinance as yf
from darts import TimeSeries

def fetch_series(ticker, start="2018-01-01"):
    df = yf.download(ticker, start=start)
    df = df[['Close']].dropna()
    return TimeSeries.from_dataframe(df)

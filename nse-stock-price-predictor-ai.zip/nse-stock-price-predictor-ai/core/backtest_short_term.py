import yfinance as yf
import pandas as pd
from darts import TimeSeries
from darts.models import RNNModel
from darts.dataprocessing.transformers import Scaler
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

ticker = "RELIANCE.NS"
df = yf.download(ticker, start="2019-01-01", end="2024-12-31")
df = df[['Close']].dropna()

series = TimeSeries.from_dataframe(df)
scaler = Scaler(StandardScaler())
series_scaled = scaler.fit_transform(series)

input_len = 60
results = []
model = RNNModel("LSTM", input_chunk_length=input_len, output_chunk_length=1, n_epochs=20, random_state=0)

for i in range(input_len + 100, len(series_scaled) - 2):
    train = series_scaled[:i]
    model.fit(train, verbose=False)
    forecast = model.predict(1)
    pred = scaler.inverse_transform(forecast).values().flatten()[0]

    today_price = series[i].values()[0][0]
    tomorrow_price = series[i+1].values()[0][0]

    signal = 0
    if pred > today_price * 1.005:
        signal = 1
    elif pred < today_price * 0.995:
        signal = -1

    daily_return = (tomorrow_price - today_price) / today_price
    strategy_return = signal * daily_return

    results.append({
        "date": series[i].time_index[-1],
        "actual": tomorrow_price,
        "predicted": pred,
        "signal": signal,
        "strategy_return": strategy_return,
        "buy_hold_return": daily_return
    })

bt = pd.DataFrame(results)
bt.set_index("date", inplace=True)
bt["strategy_cum"] = (1 + bt["strategy_return"]).cumprod()
bt["buy_hold_cum"] = (1 + bt["buy_hold_return"]).cumprod()

plt.figure(figsize=(10,6))
plt.plot(bt["strategy_cum"], label="Strategy")
plt.plot(bt["buy_hold_cum"], label="Buy & Hold")
plt.legend()
plt.title(f"Backtest for {ticker}")
plt.show()
